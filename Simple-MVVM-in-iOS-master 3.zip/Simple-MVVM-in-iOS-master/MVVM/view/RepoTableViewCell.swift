//
//  RepoTableViewCell.swift
//  MVVM
//
//  Created by Anuran Barman on 8/27/18.
//  Copyright © 2018 Anuran Barman. All rights reserved.
//

import UIKit

class RepoTableViewCell: UITableViewCell {
    
    @IBOutlet weak var repoCounterText: UILabel!
    @IBOutlet weak var repoDescText: UILabel!
    @IBOutlet weak var repoNameText: UILabel!
}
