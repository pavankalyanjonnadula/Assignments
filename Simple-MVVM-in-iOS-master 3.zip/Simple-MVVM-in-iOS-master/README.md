# Simple-MVVM-in-iOS
Simple MVVM implementation in iOS

A too simple ios App with MVVM architecture which fetches the repository of my github account and shows it to a tableview.

## Testing

1. Api testing 
2. ViewModel Testing

